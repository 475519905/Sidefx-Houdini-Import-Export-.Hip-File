import bpy
import os
import subprocess
import tempfile
import logging
import sys
import platform
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty
from bpy.types import Operator, AddonPreferences

bl_info = {
    "name": "SideFX Houdini Import-Export (.hip) File ",
    "author": "475519905",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "File > Import-Export > SideFX Houdini File (.hip)",
    "description": "Import-Export SideFX Houdini File (.hip) files.",
    "category": "Import-Export",
    "support": "COMMUNITY",
    "warning": "Houdini installation required!",
    "doc_url": "https://blendermarket.com/creators/blender-vfx-master",
}

# 设置日志
log_file = os.path.join(os.path.expanduser("~"), "Documents", "blender_houdini_log.txt")
logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    filename=log_file,
                    filemode='a')
logger = logging.getLogger(__name__)

class HoudiniPreferences(AddonPreferences):
    bl_idname = __name__

    houdini_install_path: StringProperty(
        name="Houdini Installation Path",
        description="Installation directory path for Houdini",
        subtype='DIR_PATH',
        default="C:\\Program Files\\Side Effects Software\\Houdini 20.5.278"
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "houdini_install_path")
        
        # Display current hython path
        hython_path = os.path.join(self.houdini_install_path, "bin", "hython3.11.exe")
        layout.label(text=f"Hython Path: {hython_path}")

        # First row buttons
        row = layout.row()
        row.operator(
            "wm.url_open", 
            text="Documentation",
            icon='HELP'
        ).url = "https://www.yuque.com/shouwangxingkong-0p4w3/ldvruc/uteu6czs56pwfgwn?singleDoc"
        row.operator(
            "wm.url_open", 
            text="About Author",
            icon='USER'
        ).url = "https://blendermarket.com/creators/blender-vfx-master"

        # Second row buttons
        row = layout.row()
        row.operator(
            "wm.url_open", 
            text="Check Updates",
            icon='FILE_REFRESH'
        ).url = "https://github.com/475519905/blender-Import-export-houdini-file"
        row.operator(
            "wm.url_open", 
            text="Join QQ Group",
            icon='COMMUNITY'
        ).url = "https://qm.qq.com/cgi-bin/qm/qr?k=9KgmVUQMfoGf7g_s-4tSe15oMJ6rbz6b"

        # Third row button
        row = layout.row()
        row.operator(
            "wm.url_open", 
            text="Buy Pro Version",
            icon='FUND'
        ).url = "https://blendermarket.com/creators/blender-vfx-master"

class ImportHoudiniOperator(Operator, ImportHelper):
    bl_idname = "import_scene.houdini"
    bl_label = "Import Houdini File"
    bl_description = "Import Houdini (.hip, .hipnc, .hiplc) files"

    filename_ext = ".hip"
    filter_glob: StringProperty(
        default="*.hip;*.hipnc;*.hiplc", 
        options={'HIDDEN'}
    )

    def execute(self, context):
        logger.info("Starting Houdini import operation")
        try:
            # 创建临时目录
            temp_dir = os.path.join(os.path.expanduser("~"), "Documents", "cache")
            os.makedirs(temp_dir, exist_ok=True)
            
            # 获取Houdini安装路径
            preferences = context.preferences.addons[__name__].preferences
            houdini_path = preferences.houdini_install_path.rstrip("\\")
            
            # 设置基本环境变量
            env = os.environ.copy()
            env["HFS"] = houdini_path
            
            # 处理文件路径，确保使用正斜杠
            hip_file_path = self.filepath.replace("\\", "/")
            fbx_temp_path = os.path.join(temp_dir, "temp.fbx").replace("\\", "/")
            
            # 创建Houdini脚本
            script_content = f'''
import sys
import os
print("Python版本:", sys.version)
print("Python路径:", sys.path)
print("当前工作目录:", os.getcwd())

try:
    print("正在导入hou模块...")
    import hou
    print("hou模块导入成功!")
    print("Houdini版本:", hou.applicationVersion())
    
    print("正在加载hip文件...")
    hip_path = r"{hip_file_path}"
    print(f"Hip文件路径: {{hip_path}}")
    hou.hipFile.load(hip_path, ignore_load_warnings=True)
    print("hip文件加载成功!")
    
    print("开始导出FBX...")
    # 导出为FBX
    obj_context = hou.node("/obj")
    if not obj_context:
        raise Exception("无法找到 /obj 上下文")
    
    rop_context = hou.node("/out")
    if not rop_context:
        print("创建 /out 上下文...")
        rop_context = obj_context.createNode("ropnet")
    
    print("创建FBX输出节点...")
    fbx_node = rop_context.createNode("filmboxfbx")
    
    # 设置FBX导出参数
    fbx_node.parm("sopoutput").set(r"{fbx_temp_path}")
    fbx_node.parm("startnode").set("/obj")
    fbx_node.parm("exportkind").set(0)  # 导出整个场景
    fbx_node.parm("sdkversion").set("FBX | FBX201800")  # 使用较新的FBX版本
    fbx_node.parm("vcformat").set(1)  # 设置顶点缓存格式
    
    print("执行FBX导出...")
    fbx_node.render()
    print("FBX导出完成!")
    
    # 清理节点
    fbx_node.destroy()
    
except Exception as e:
    print(f"执行出错: {{str(e)}}", file=sys.stderr)
    import traceback
    print(traceback.format_exc(), file=sys.stderr)
    raise
'''
            # 保存脚本
            script_path = os.path.join(temp_dir, "import_hou.py")
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(script_content)
            
            # 构建hython路径
            hython_path = os.path.join(houdini_path, "bin", "hython3.11.exe")
            
            if not os.path.exists(hython_path):
                logger.error(f"找不到Hython: {hython_path}")
                self.report({'ERROR'}, f"找不到Hython: {hython_path}")
                return {'CANCELLED'}
            
            # 运行脚本
            logger.info(f"Running Hython script: {script_path}")
            result = subprocess.run([hython_path, script_path], 
                                 env=env,
                                 check=False,  # 改为False以获取更多错误信息
                                 capture_output=True, 
                                 text=True)
            
            # 输出所有信息
            if result.stdout:
                logger.info(f"标准输出:\n{result.stdout}")
            if result.stderr:
                logger.error(f"错误输出:\n{result.stderr}")
            
            if result.returncode != 0:
                self.report({'ERROR'}, f"Houdini脚本执行失败。请查看日志文件: {log_file}")
                return {'CANCELLED'}
            
            # 导入生成的FBX
            fbx_path = os.path.join(temp_dir, "temp.fbx")
            if os.path.exists(fbx_path):
                # 导入FBX
                bpy.ops.import_scene.fbx(filepath=fbx_path)
                
                # 处理所有新导入的对象
                for obj in bpy.context.selected_objects:
                    if obj.type == 'MESH':
                        # 重置缩放为1
                        obj.scale = (1.0, 1.0, 1.0)
                        obj.select_set(True)
                        bpy.context.view_layer.objects.active = obj
                        
                        # 应用缩放
                        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                
                os.remove(fbx_path)  # 清理临时文件
                logger.info("Houdini import operation completed")
                self.report({'INFO'}, "Import successful!")
            else:
                logger.error(f"Exported FBX file not found: {fbx_path}")
                self.report({'ERROR'}, "Exported FBX file not found")
                return {'CANCELLED'}
            
            return {'FINISHED'}
            
        except Exception as e:
            logger.error(f"执行过程中出错: {str(e)}")
            self.report({'ERROR'}, f"执行失败: {str(e)}")
            return {'CANCELLED'}

def menu_func_import(self, context):
    self.layout.operator(
        ImportHoudiniOperator.bl_idname, 
        text="Import SideFX Houdini (.hip .hipnc .hiplc) File"
    )

def register():
    bpy.utils.register_class(HoudiniPreferences)
    bpy.utils.register_class(ImportHoudiniOperator)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)

def unregister():
    bpy.utils.unregister_class(HoudiniPreferences)
    bpy.utils.unregister_class(ImportHoudiniOperator)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)

if __name__ == "__main__":
    register()
